---
title: "NEWS"
author: "Kridsadakorn Chaichoompu"
date: "04/06/2018"
output:
  html_document:
    keep_md: yes
    toc: yes
  pdf_document: 
    number_sections: yes
    toc: yes
---



# FILEST 1.0.1

## Updates

* FILEST 1.0.1 is released under GPL-2|GPL-3

# FILEST 1.0.0

## NOTES

* Shift from 0.3.7 to 1.0.0 to release

## Updates

* Romoved all codes related to doMC and doParallel, there is a problem in Windows.

# FILEST 0.3.7

## Updates

* Added all manual files for all functions
* Added all unit tests

## Changes

* Removed save.PC.plot() and replaced with KRIS::plot3views

# FILEST 0.3.6

## Initial project in GitLab

* Uploaded and Synchronized all files
