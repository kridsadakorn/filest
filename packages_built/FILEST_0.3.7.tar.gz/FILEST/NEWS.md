---
title: "NEWS"
author: "Kridsadakorn Chaichoompu"
date: "04/06/2018"
output:
  html_document:
    keep_md: yes
    toc: yes
  pdf_document: 
    number_sections: yes
    toc: yes
---




# FILEST 0.3.7

## Updates

* Added all manual files for all functions
* Added all unit tests

## Changes

* Removed save.PC.plot() and replaced with KRIS::plot3views

# FILEST 0.3.6

## Initial project in GitLab

* Uploaded and Synchronized all files
